---
layout: default
title: Home
---

# Welcome to My Simple Jekyll Website 👋

This is a tiny Jekyll site created for learning.

Here is my first blog post:

- [First Post](/first-post)
